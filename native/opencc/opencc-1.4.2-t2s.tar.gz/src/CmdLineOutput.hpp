/*
 * Open Chinese Convert
 *
 * Copyright 2010-2014 Carbo Kuo <byvoid@byvoid.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#pragma once

#include "tclap/CmdLine.h"

class CmdLineOutput : public TCLAP::StdOutput {
public:
  virtual void usage(TCLAP::CmdLineInterface& cmd) {
    std::cout << std::endl
              << cmd.getMessage() << std::endl
              << "Author: Carbo Kuo <byvoid@byvoid.com>" << std::endl
              << "Bug Report: https://github.com/BYVoid/OpenCC/issues"
              << std::endl
              << std::endl
              << "Usage: " << std::endl
              << std::endl;

    _shortUsage(cmd, std::cout);
    std::cout << std::endl;
    std::cout << "Options: " << std::endl << std::endl;
    _longUsage(cmd, std::cout);
    std::cout << std::endl;
  }

  virtual void version(TCLAP::CmdLineInterface& cmd) {
    std::cout << std::endl
              << cmd.getMessage() << std::endl
              << "Version: " << cmd.getVersion() << std::endl
              << std::endl;
  }
};

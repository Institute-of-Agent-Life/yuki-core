from pathlib import Path
import json,sys,traceback,tempfile
root=Path(sys.argv[1]);out=Path(sys.argv[2]);sys.path.insert(0,str(root))
from tests.harness import Context
from tests.harness.gateway_mentions import run
from tests.harness.network import install
install();ctx=Context(root,out,json.loads((root/'ci/checks.json').read_bytes()));ctx.working=Path(tempfile.mkdtemp(prefix='ymp-',dir='/tmp'));ctx.write('working-directory.json',{'path':str(ctx.working)})
try:ctx.write('gateway-mentions.json',run(ctx,root/'sdk/python','release'));print('PASS',len(ctx.assertions),flush=True)
except Exception:ctx.write('failure.json',{'traceback':traceback.format_exc()});raise
finally:ctx.write('assertions.json',ctx.assertions)

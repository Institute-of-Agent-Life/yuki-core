from pathlib import Path
import fcntl,hashlib,json,subprocess,sys,zipfile
root=Path('/Volumes/huawei/項目實戰/yuki-core');source=root/'.cache/worktrees/mention-paging';out=Path(__file__).resolve().parent
names=subprocess.check_output(['git','ls-files','-co','--exclude-standard','-z'],cwd=source,stderr=subprocess.DEVNULL).decode().split('\0')
files={n:hashlib.sha256((source/n).read_bytes()).hexdigest() for n in sorted(set(names)) if n and n != 'target' and not n.startswith('artifacts/') and not any(p.startswith('._') for p in Path(n).parts)}
identity={'commit':'8a849d306d87e44525ee9e53be3afbdae21f2fe8','branch':'codex/core-025-mention-paging','dirty':True,'tree_sha256':hashlib.sha256(json.dumps(files,sort_keys=True).encode()).hexdigest(),'files':files,'scope':'diagnostic executable source, fixtures and docs; generated artifacts excluded'}
archive=out/'source-05.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for n in files:z.write(source/n,n)
 z.writestr('.yuki-source.json',json.dumps(identity))
(out/'source-05.json').write_text(json.dumps(identity,indent=2)+'\n')
with (root/'.cache/local-ci-windows.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX);parent='D:/yuki-core-validation-20261104'
 for local,remote in [(archive,'mention-paging-source-05.zip'),(out/'windows_preflight_05.py','mention-paging-preflight-05.py'),(out/'windows_replay_05.py','mention-paging-replay-05.py')]:
  subprocess.run(['scp','-q',str(local),'hjw:'+parent+'/'+remote],check=True)
 with (out/'windows-05.log').open('xb') as log:r=subprocess.run(['ssh','hjw','py','-3.12',parent+'/mention-paging-preflight-05.py',hashlib.sha256(archive.read_bytes()).hexdigest()],stdout=log,stderr=subprocess.STDOUT)
 subprocess.run(['scp','-q','hjw:'+parent+'/mention-paging-result-05.zip',str(out/'windows-result-05.zip')],check=True)
 print('WINDOWS PREFLIGHT EXIT',r.returncode,flush=True);raise SystemExit(r.returncode)

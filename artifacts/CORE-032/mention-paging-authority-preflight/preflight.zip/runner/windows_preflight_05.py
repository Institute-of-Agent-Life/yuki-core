"""Compile and replay the exact dirty diagnostic snapshot on HJW."""
from pathlib import Path
import hashlib,json,msvcrt,os,shutil,subprocess,sys,zipfile
parent=Path('D:/yuki-core-validation-20261104');root=parent/'MENTION-PAGING-PREFLIGHT-05'
archive=parent/'mention-paging-source-05.zip';assert hashlib.sha256(archive.read_bytes()).hexdigest()==sys.argv[1]
profile=json.loads((Path.home()/'yuki-core-tooling/environment.json').read_bytes());cache=parent/'codex-native-cargo-cache-01'
with (cache/'exclusive.lock').open('r+b') as lock:
 msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1);root.mkdir()
 with zipfile.ZipFile(archive) as z:
  assert all((root/n).resolve().is_relative_to(root) for n in z.namelist());z.extractall(root)
 out=root/'artifacts/preflight';out.mkdir(parents=True);temporary=root/'.cache/tmp';temporary.mkdir(parents=True)
 env=dict(os.environ,CARGO_HOME=profile['cargo_home'],RUSTUP_HOME=profile['rustup_home'],YUKI_MINGW_BIN=profile['mingw_bin'],TEMP=str(temporary),TMP=str(temporary),CARGO_INCREMENTAL='0',YUKI_FEISHU_CURL='C:/Program Files/Git/mingw64/bin/curl.exe',PYTHONUTF8='1',UV_FIND_LINKS='D:/yuki-extension-tests/feishu-mentions-20261107-01/mentions-01/wheels')
 env['PATH']=os.pathsep.join([str(Path(profile['cargo_home'])/'bin'),profile['mingw_bin'],env['PATH']])
 env.update(CC=str(Path(profile['mingw_bin'])/'gcc.exe'),CXX=str(Path(profile['mingw_bin'])/'g++.exe'),AR=str(Path(profile['mingw_bin'])/'ar.exe'))
 env.update(CARGO_TARGET_X86_64_PC_WINDOWS_GNU_LINKER=str(Path(profile['mingw_bin'])/'gcc.exe'),CARGO_ENCODED_RUSTFLAGS='\x1f'.join(['-C','link-self-contained=no','-C','dlltool='+str(Path(profile['mingw_bin'])/'dlltool.exe')]))
 target=root/'target';subprocess.run(['cmd','/d','/c','mklink','/J',str(target),str(cache/'target')],check=True,capture_output=True)
 code=1
 try:
  with (out/'build.log').open('wb') as log:
   subprocess.run([str(Path(profile['cargo_home'])/'bin/cargo.exe'),'build','--locked','--offline'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  binary=cache/'target/debug/yuki-core.exe';shutil.copyfile(binary,out/'yuki-core.exe')
  with zipfile.ZipFile(out/'unsigned-host.zip','x',zipfile.ZIP_DEFLATED) as z:
   z.write(out/'yuki-core.exe','yuki-core.exe');z.write(root/'.yuki-source.json','source.json')
  runner=parent/'mention-paging-replay-05.py'
  with (out/'replay.log').open('wb') as log:code=subprocess.run([sys.executable,str(runner),str(root),str(out)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 finally:
  assert target.is_junction();target.rmdir()
  with zipfile.ZipFile(parent/'mention-paging-result-05.zip','x',zipfile.ZIP_DEFLATED) as z:
   for p in out.rglob('*'):
    if p.is_file() and 'work' not in p.relative_to(out).parts:z.write(p,p.relative_to(out))
 print('PREFLIGHT EXIT',code,flush=True)
 raise SystemExit(code)

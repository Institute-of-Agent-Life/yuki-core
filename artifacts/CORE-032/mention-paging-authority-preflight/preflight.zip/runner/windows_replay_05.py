from pathlib import Path
import hashlib,json,shutil,sys,traceback
root=Path(sys.argv[1]);out=Path(sys.argv[2]);sys.path.insert(0,str(root))
from tests.harness import Context
from tests.harness.gateway_mentions import run
from tests.harness.network import install
install()
from tests.harness.json_file import take_command
mailbox=out/'locked-probe.json'
original={'method':'gateway.inbound','params':{'source':'original'}}
mailbox.write_text(json.dumps(original),encoding='utf8')
with mailbox.open('rb'):
    assert json.loads(mailbox.read_bytes())==original
    try:
        mailbox.unlink()
    except PermissionError as error:
        assert error.errno==13
        blocked={'errno':error.errno,'winerror':error.winerror}
    else:
        raise AssertionError('Original direct unlink did not encounter the Windows lock')
    assert take_command(mailbox) is None and json.loads(mailbox.read_bytes())==original
assert take_command(mailbox)==original and take_command(mailbox) is None
(out/'mailbox-lock.json').write_text(json.dumps({'status':'PASS','old_unlink':blocked,'deferred':True,'claimed_after_release':True,'duplicate':False},indent=2)+'\n')
focused=out/'core';focused.mkdir();ctx=Context(root,focused,json.loads((root/'ci/checks.json').read_bytes()));ctx.working=focused/'work';ctx.working.mkdir()
try:ctx.write('gateway-mentions.json',run(ctx,root/'sdk/python','debug'));print('CORE PASS',len(ctx.assertions),flush=True)
except Exception:ctx.write('failure.json',{'traceback':traceback.format_exc()});raise
finally:ctx.write('assertions.json',ctx.assertions)
ext=Path('D:/yuki-extension-tests/feishu-mentions-20261107-01/mentions-01');repo=ext/'src'
sys.path[:0]=[str(repo/'ci'),str(repo/'tests/peers')]
import feishu_delivery
source=json.loads((root/'.yuki-source.json').read_bytes());binary=out/'yuki-core.exe';host_sha=hashlib.sha256(binary.read_bytes()).hexdigest();zip_sha=hashlib.sha256((out/'unsigned-host.zip').read_bytes()).hexdigest()
def original_host(_root,work,contract):
 pin=json.loads((repo/'compat'/contract/'source.lock.json').read_bytes());pin.update(source_commit=source['commit'],source_tree_sha256=source['tree_sha256'],dirty=True)
 target={'binary_sha256':host_sha,'sha256':zip_sha};local=work/'yuki-core.exe';shutil.copyfile(binary,local)
 return local,pin,target
feishu_delivery.materialize=original_host
cases=[]
for index,domain in enumerate(['feishu','lark','feishu']):
 proof=feishu_delivery.exercise(repo,ext/'evidence/delivery/packages',out/f'consumer-{index}',domain,'mention-parts')
 cases.append(proof);print('ACTUAL CONSUMER PASS',index,domain,flush=True)
(out/'diagnostic.json').write_text(json.dumps({'status':'PREFLIGHT_PASS','source':source,'unsigned_host_sha256':host_sha,'unsigned_host_archive_sha256':zip_sha,'source_dirty':True,'consumer_snapshot':'a173898f757e1e3ecd337d77ecc6cccba942fb1d7275c910b1c139848d000bd4','cases':cases,'formal_acceptance':False},indent=2)+'\n')

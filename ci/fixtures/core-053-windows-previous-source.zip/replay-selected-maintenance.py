"""Replay selected maintenance plus the exact previously qualified native consumers."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from zipfile import ZipFile

from run_previous_selected import exercise as original_base


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def write(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write('\n')


def materialize(path, destination):
    destination.mkdir()
    with ZipFile(path) as archive:
        assert archive.testzip() is None
        names = archive.namelist()
        assert len(names) == len(set(name.casefold() for name in names))
        assert all(Path(name).name == name for name in names)
        archive.extractall(destination)
    package = read(destination / 'package-manifest.json')
    assert all(digest(destination / name) == wanted for name, wanted in package['artifacts'].items())
    return package


def run(args):
    host_build = read(args.host_build)
    host = args.host_build.with_name(host_build['binary']['path'])
    plan = args.host_build.with_name('plan.json')
    manifest = args.kit / 'support-manifest.json'
    kit = read(manifest)
    descriptor = json.loads(subprocess.check_output([host, 'plugin-surface'], timeout=15))
    assert descriptor == host_build['profile']
    assert digest(host) == host_build['binary']['sha256'] and digest(plan) == host_build['plan_sha256']
    assert kit['source_commit'] == descriptor['candidate_source'] and kit['version'] == descriptor['version']
    assert sorted(kit['methods']) == descriptor['methods']
    assert all(digest(args.kit / name) == wanted for name, wanted in kit['files'].items())

    args.out.mkdir()
    os.environ['PYTHONUTF8'] = '1'
    os.environ['PYTHONIOENCODING'] = 'utf-8'
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    sys.dont_write_bytecode = True
    system = args.system
    pins = read(args.inputs / 'bindings.json')
    assert pins['platform'] == system
    for name, wanted in pins['files'].items():
        assert digest(args.inputs / name) == wanted, name
    assert digest(args.inputs / 'quality.zip') == pins['quality_package_sha256']
    assert digest(args.inputs / 'feishu.zip') == pins['feishu_package_sha256']
    for unit in ('telegram', 'web-fetch'):
        for binary in (args.inputs / 'base' / unit).glob('yuki-*'):
            if binary.is_file():
                binary.chmod(0o700)
    if os.name != 'nt':
        os.environ['TMPDIR'] = str(args.tmp)
    original_base(
        args.host_build, args.kit, args.inputs / 'base', read(args.inputs / 'previous.json'),
        args.inputs / 'base-harness/joint.py', args.out / 'previous-base',
    )
    profile = {'source_commit': descriptor['candidate_source'], 'schema_sha256': descriptor['surface_sha256']}
    binding = {'binary_sha256': digest(host), 'sha256': None}
    with tempfile.TemporaryDirectory(prefix='ysq-', dir=args.tmp) as folder:
        scratch = Path(folder)
        os.environ['TMPDIR'] = str(scratch)
        os.environ['TEMP'] = str(scratch)
        os.environ['TMP'] = str(scratch)
        root = args.inputs / 'ext'
        sys.path[:0] = [str(root / 'ci'), str(root / 'tests/peers')]
        import feishu_delivery

        os.environ['UV_FIND_LINKS'] = str(args.inputs / 'wheels')
        if args.curl:
            os.environ['YUKI_FEISHU_CURL'] = args.curl
        feishu = scratch / 'f'
        feishu_package = materialize(args.inputs / 'feishu.zip', feishu)
        feishu_binary = feishu / ('yuki-feishu.exe' if os.name == 'nt' else 'yuki-feishu')
        feishu_binary.chmod(0o700)
        reports = {}
        for domain in ('feishu', 'lark'):
            for scenario in ('mention-caption', 'denied', 'recall'):
                destination = scratch / (domain + '-' + scenario)
                receipt = feishu_delivery.exercise(root, feishu, destination, domain, scenario,
                                                  released_host=(host, profile, binding))
                assert receipt['status'] == 'PASS' and receipt['paid_calls'] == 0
                assert receipt['original_receipt_reopened'] and receipt['host_sha256'] == digest(host)
                assert receipt['plugin_sha256'] == digest(feishu_binary)
                expected = 'failed' if scenario == 'denied' else 'confirmed'
                assert receipt['state'] == expected
                if scenario == 'denied':
                    assert receipt['native_requests'] == receipt['token_issuances'] == 0
                evidence = args.out / 'feishu' / domain / scenario
                evidence.mkdir(parents=True)
                for name in ('delivery.json', 'wire.jsonl'):
                    shutil.copyfile(destination / name, evidence / name)
                reports[f'{domain}/{scenario}'] = {
                    'receipt': digest(evidence / 'delivery.json'), 'wire': digest(evidence / 'wire.jsonl'),
                }
                print(system, domain, scenario, expected, flush=True)

        import runpy
        from contextlib import contextmanager
        import personal_preview

        quality = scratch / 'q'
        quality_package = materialize(args.inputs / 'quality.zip', quality)
        program = quality / ('yuki-memory-maintenance.exe' if os.name == 'nt' else 'yuki-memory-maintenance')
        program.chmod(0o700)
        consumer_sdk = read(root / 'compat/core-035/source.lock.json')
        selected_pin = {**profile, 'sdk': consumer_sdk['sdk'],
                        'rust_crate_sha256': consumer_sdk['rust_crate_sha256']}
        def materialize_host(*_):
            return host, selected_pin, binding
        def install(_root, _unit, destination):
            shutil.copytree(quality, destination)
            return quality_package
        class NativeOwner(personal_preview.Owner):
            def command(self, *arguments):
                return subprocess.run([self.exe, '--data', self.data, *arguments], cwd=self.work,
                                      env=self.env, capture_output=True, text=True,
                                      encoding='utf-8', timeout=self.command_timeout)

        personal_preview.Owner = NativeOwner
        original = personal_preview.Owner.__init__
        def initialize(self, *arguments, **keywords):
            original(self, *arguments, **keywords, package_builder=install)
            config = self.data / 'yuki.toml'
            current = config.read_text(encoding='utf-8')
            relay = json.dumps(str(root / 'tests/peers/observe_stdio.py'))
            selected_relay = json.dumps(str(root / 'tests/peers/observe_quality_stdio.py'))
            assert current.count(relay) == 1
            config.write_text(current.replace(relay, selected_relay), encoding='utf-8')
        personal_preview.materialize = materialize_host
        personal_preview.Owner.__init__ = initialize
        case = runpy.run_path(str(root / 'tests/cases/EXT-036.py'))
        running = personal_preview.Owner.running
        @contextmanager
        def wait_then_run(self):
            case['wait_for_worker_exit'](Path(self.env['YUKI_MEMORY_MAINTENANCE_JOBS']))
            with running(self):
                yield
        personal_preview.Owner.running = wait_then_run
        destination = scratch / 'm'
        destination.mkdir()
        evidence = args.out / 'maintenance'
        evidence.mkdir()
        try:
            label, result = case['prepare'](root, destination, integrity=True, retain=True)
            assert result['status'] == 'PASS' and result['plugin']['binary_sha256'] == digest(program)
            write(destination / label, result)
        finally:
            for path in destination.iterdir():
                if path.is_file():
                    shutil.copyfile(path, evidence / path.name)
            trace = destination / 'work/wire.jsonl'
            if trace.is_file():
                shutil.copyfile(trace, evidence / 'observed-wire.jsonl')
        print(system, 'maintenance', len(result['cases']), 'PASS', flush=True)
    write(args.out / 'result.json', {
        'status': 'PASS', 'published': False, 'platform': system, 'paid_calls': 0,
        'candidate_source': descriptor['candidate_source'], 'plan_sha256': digest(plan),
        'input_bindings_sha256': digest(args.inputs / 'bindings.json'),
        'artifacts': {'host': digest(host), 'rust-sdk': digest(args.kit / kit['rust_sdk']),
                      'python-sdk': digest(args.kit / kit['python_sdk'])},
        'selected_sdk_manifest_sha256': digest(manifest),
        'feishu_package_sha256': pins['feishu_package_sha256'],
        'quality_package_sha256': pins['quality_package_sha256'],
        'feishu': reports,
        'maintenance': {'receipt': digest(evidence / label), 'wire': digest(evidence / 'observed-wire.jsonl')},
        'previous_base': digest(args.out / 'previous-base/result.json'),
        'temporary_directory_removed': not scratch.exists(),
    })


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('host-build', 'kit', 'inputs', 'tmp', 'out'):
        parser.add_argument('--' + name, required=True, type=lambda value: Path(value).resolve())
    parser.add_argument('--system', required=True, choices=('macos', 'linux', 'windows'))
    parser.add_argument('--curl', default='')
    run(parser.parse_args())

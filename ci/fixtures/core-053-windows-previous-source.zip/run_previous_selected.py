"""Replay original B0 consumers on an exact local selected Host and SDK pair."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import zipfile


def read(path):
    return json.loads(path.read_bytes())


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def exercise(host_build_file, kit, assets, previous, harness, out):
    plan_file = host_build_file.with_name("plan.json")
    profile = read(plan_file)
    host_build = read(host_build_file)
    host = host_build_file.parent / host_build["binary"]["path"]
    descriptor = json.loads(subprocess.check_output([host, "plugin-surface"], timeout=15))
    assert descriptor == host_build["profile"]
    assert sha(host) == host_build["binary"]["sha256"]
    assert sha(plan_file) == host_build["plan_sha256"]
    assert not host_build["source"]["dirty"]
    assert descriptor["candidate_source"] == host_build["source"]["commit"] == profile["candidate_source"]
    assert descriptor["surface_sha256"] == profile["surface_sha256"]
    assert descriptor["methods"] == sorted(["initialize", *profile["surface"]["methods"]])
    sdk = read(kit / "support-manifest.json")
    assert sdk["source_commit"] == profile["candidate_source"] and sdk["version"] == profile["version"]
    assert sorted(sdk["methods"]) == descriptor["methods"]
    assert all(sha(kit / name) == expected for name, expected in sdk["files"].items())
    out.mkdir()
    files = {"host": sha(host), "rust-sdk": sdk["files"][sdk["rust_sdk"]],
             "python-sdk": sdk["files"][sdk["python_sdk"]]}
    for unit, members in previous["pin"]["packages"].items():
        with zipfile.ZipFile(out / (unit + "-original-1.0.zip"), "x", zipfile.ZIP_DEFLATED) as archive:
            for name, expected in members.items():
                path = assets / unit / name
                assert Path(name).name == name and sha(path) == expected
                archive.write(path, name)
        with zipfile.ZipFile(out / (unit + "-original-1.0.zip")) as archive:
            for name, expected in members.items():
                assert hashlib.sha256(archive.read(name)).hexdigest() == expected
    pin = dict(previous["pin"], host=files["host"], source=profile["candidate_source"])
    write(out / "prior-pin.json", previous["pin"])
    write(out / "replay-pin.json", pin)
    env = dict(os.environ)
    if os.name != "nt":
        env["TMPDIR"] = "/tmp"
    with tempfile.TemporaryDirectory(prefix="yb1-", dir="/tmp" if os.name != "nt" else None) as temp:
        folder = Path(temp).resolve()
        shutil.copyfile(harness, folder / "joint.py")
        shutil.copyfile(harness.with_name("relay.py"), folder / "relay.py")
        scenarios = ("confirmed", "revoked", "lost-second", "wrong-handle",
                     "swapped", "missing-method", "erased-readback")
        for scenario in scenarios:
            with (out / (scenario + ".log")).open("xb") as log:
                subprocess.run(
                    [sys.executable, folder / "joint.py", assets, host,
                     out / "replay-pin.json", out / scenario, "--case", scenario,
                     "--blocked-grant", "gateway.activity", "--surface-plan", plan_file],
                    env=env, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=180,
                )
            result = read(out / scenario / "result.json")
            assert result["status"] == "PASS" and result["host"] == files["host"]
            assert result["packages"] == previous["pin"]["packages"]
            assert result["redelivered_old_update"] and result["post_restart_effects"] == 0
            print(scenario, "PASS", flush=True)
    write(out / "result.json", {
        "status": "PASS",
        "published": False,
        "source_commit": profile["candidate_source"],
        "source_tree_sha256": host_build["source"]["tree_sha256"],
        "prior_release_sha256": previous["pin"]["base_archive"],
        "prior_qualification_sha256": previous["base_case_receipt_sha256"],
        "plan_sha256": sha(plan_file),
        "artifacts": files,
        "consumer_cases": {
            scenario: {
                "result_sha256": sha(out / scenario / "result.json"),
                "wires": {unit: sha(out / scenario / (unit + ".jsonl"))
                          for unit in previous["pin"]["packages"]},
            }
            for scenario in scenarios
        },
        "consumer_packages": {unit: sha(out / (unit + "-original-1.0.zip"))
                              for unit in previous["pin"]["packages"]},
        "harness": {name: sha(harness.with_name(name)) for name in ("joint.py", "relay.py")},
        "paid_calls": 0,
    })


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("host_build", "kit", "assets", "previous", "harness", "out"):
        parser.add_argument(name, type=lambda s: Path(s).resolve())
    args = parser.parse_args()
    exercise(args.host_build, args.kit, args.assets, read(args.previous), args.harness, args.out)
